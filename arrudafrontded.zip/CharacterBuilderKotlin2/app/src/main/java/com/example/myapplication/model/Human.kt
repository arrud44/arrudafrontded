package com.example.myapplication.model

class Human : Race("Humano", mapOf(
    "Força" to 1,
    "Destreza" to 1,
    "Constituição" to 1,
    "Inteligência" to 1,
    "Sabedoria" to 1,
    "Carisma" to 1
))