package com.example.myapplication.model

class Gnome : Race("Gnomo", mapOf(
    "Inteligência" to 2
))