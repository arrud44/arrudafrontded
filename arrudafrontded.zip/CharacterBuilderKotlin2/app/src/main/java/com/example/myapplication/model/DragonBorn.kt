package com.example.myapplication.model

class DragonBorn : Race("Draconato", mapOf(
    "Força" to 2,
    "Carisma" to 1
))